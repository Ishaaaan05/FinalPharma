﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PharmaPlus.Models
{
    public partial class Order
    {
        [Key]
        public int OrderId { get; set; }

        [ForeignKey(nameof(PlacedByUser))]
        public int UserId { get; set; }

        [Column(TypeName = "datetime")]
        public DateTime? OrderDate { get; set; }

        [Required]
        [StringLength(50)]
        public string Status { get; set; } = "Pending";

        [Column(TypeName = "decimal(10, 2)")]
        public decimal TotalAmount { get; set; }

        [ForeignKey(nameof(VerifiedByUser))]
        public int? VerifiedBy { get; set; } // ID of Admin who verified the order

        public virtual User PlacedByUser { get; set; } = null!; // User who placed the order

        public virtual User? VerifiedByUser { get; set; }  // Admin who verified the order

        public virtual ICollection<OrderDetail> OrderDetails { get; set; } = new List<OrderDetail>(); // List of drugs in the order
    }
}
