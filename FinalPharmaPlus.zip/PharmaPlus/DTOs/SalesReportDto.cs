namespace PharmaPlus.DTOs
{
    public class SalesReportDto
    {
        public int ReportId { get; set; }
        public int AdminId { get; set; }
        public DateTime GeneratedDate { get; set; }
        public decimal TotalSales { get; set; }
        public decimal TotalRevenue { get; set; }
        public int TotalItemsSold { get; set; }
        public List<SalesReportDetailDto> SalesReportDetails { get; set; } = new List<SalesReportDetailDto>();
    }
}

