﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace PharmaPlus.Models
{
    public partial class Supplier
    {
        [Key]
        public int SupplierId { get; set; }

        [Required]
        [StringLength(100)]
        public string SupplierName { get; set; } = null!;

        [Required]
        [StringLength(15)]
        public string Contact { get; set; } = null!;

        [StringLength(100)]
        public string? Email { get; set; }

        [StringLength(200)]
        public string? Address { get; set; }

        public virtual ICollection<Drug> DrugsSupplied { get; set; } = new List<Drug>();

    }
}
