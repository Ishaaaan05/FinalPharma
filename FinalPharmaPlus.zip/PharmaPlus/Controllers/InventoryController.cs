using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PharmaPlus.Data;
using PharmaPlus.Filters;
using PharmaPlus.Models;


namespace PharmaPlus.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ServiceFilter(typeof(AdminAuthorizeAttribute))]
    [Authorize]
    public class InventoryController : ControllerBase
    {
        private readonly PharmaPlusContext _context;

        public InventoryController(PharmaPlusContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<InventoryList>>> GetInventoryLists()
        {
            return await _context.InventoryLists
                .Include(il => il.Drug)
                .Include(il => il.Supplier)
                .ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<InventoryList>> GetInventoryList(int id)
        {
            var inventoryList = await _context.InventoryLists
                .Include(il => il.Drug)
                .Include(il => il.Supplier)
                .FirstOrDefaultAsync(il => il.InventoryListId == id);

            if (inventoryList == null)
            {
                return NotFound();
            }

            return inventoryList;
        }

        [HttpGet("suppliers")]
        public async Task<ActionResult<IEnumerable<Supplier>>> GetSuppliers()
        {
            return await _context.Suppliers.ToListAsync();
        }

        [HttpPost("auto-restock")]
        public async Task<IActionResult> AutoRestock()
        {
            var pendingOrders = await _context.Orders
                .Include(o => o.OrderDetails)
                .Where(o => o.Status == "Pending")
                .ToListAsync();

            var drugQuantities = pendingOrders
                .SelectMany(o => o.OrderDetails)
                .GroupBy(od => od.DrugId)
                .Select(g => new
                {
                    DrugId = g.Key,
                    Quantity = g.Sum(od => od.Quantity) + 50 // Pending orders quantity + 50
                })
                .ToList();

            foreach (var drugQuantity in drugQuantities)
            {
                var drug = await _context.Drugs.Include(d => d.Supplier).FirstOrDefaultAsync(d => d.DrugId == drugQuantity.DrugId);
                if (drug == null || drug.Supplier == null)
                {
                    continue; // Skip if drug or supplier is not found
                }

                var inventoryList = new InventoryList
                {
                    DrugId = drug.DrugId,
                    SupplierId = drug.Supplier.SupplierId,
                    QuantityInStock = drugQuantity.Quantity,
                    UnitPrice = drug.Price,
                    TotalCost = drug.Price * drugQuantity.Quantity,
                    ReorderLevel = 20, // Example reorder level
                    LastRestockDate = DateTime.UtcNow,
                    ExpiryDate = DateTime.UtcNow.AddYears(2),
                    Drug = drug,
                    Supplier = drug.Supplier
                };

                _context.InventoryLists.Add(inventoryList);
            }

            await _context.SaveChangesAsync();

            return NoContent();
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutInventoryList(int id, InventoryList inventoryList)
        {
            if (id != inventoryList.InventoryListId)
            {
                return BadRequest();
            }

            var drug = await _context.Drugs.Include(d => d.Supplier).FirstOrDefaultAsync(d => d.DrugName == inventoryList.Drug.DrugName);
            if (drug == null)
            {
                return BadRequest("Drug not found.");
            }

            var supplier = drug.Supplier;
            if (supplier == null)
            {
                return BadRequest("Supplier not found.");
            }

            inventoryList.DrugId = drug.DrugId;
            inventoryList.SupplierId = supplier.SupplierId;
            inventoryList.UnitPrice = drug.Price;
            inventoryList.TotalCost = inventoryList.UnitPrice * inventoryList.QuantityInStock;

            _context.Entry(inventoryList).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!InventoryListExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        [HttpPost("restock/{inventoryId}")]
        public async Task<IActionResult> RestockInventory(int inventoryId, [FromBody] int quantity)
        {
            var inventory = await _context.InventoryLists.FindAsync(inventoryId);
            if (inventory == null)
            {
                return NotFound();
            }

            inventory.QuantityInStock += quantity;
            inventory.LastRestockDate = DateTime.UtcNow;
            inventory.TotalCost = inventory.UnitPrice * inventory.QuantityInStock;
            await _context.SaveChangesAsync();

            return NoContent();
        }

      

        [HttpGet("expired")]
        public async Task<ActionResult<IEnumerable<InventoryList>>> GetExpiredItems()
        {
            var expiredItems = await _context.InventoryLists
                .Where(il => il.ExpiryDate <= DateTime.Now)
                .Include(il => il.Drug)
                .Include(il => il.Supplier)
                .ToListAsync();

            return expiredItems;
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteInventoryList(int id)
        {
            var inventoryList = await _context.InventoryLists.FindAsync(id);
            if (inventoryList == null)
            {
                return NotFound();
            }

            _context.InventoryLists.Remove(inventoryList);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool InventoryListExists(int id)
        {
            return _context.InventoryLists.Any(e => e.InventoryListId == id);
        }
    }
}