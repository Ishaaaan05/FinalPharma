using MailKit.Net.Smtp;
using MimeKit;
using System.Threading.Tasks;

namespace PharmaPlus.Services
{
    public class EmailService
    {
        private readonly string smtpServer = "smtp.gmail.com"; // Use Gmail's SMTP server
        private readonly int smtpPort = 587; // Use port 587 for TLS
        private readonly string smtpUser = "kanadiaishan05@gmail.com";  // Your Gmail address
        private readonly string smtpPass = "yngnecgxnhnzcsev"; // Your Gmail App Password

        public async Task SendEmailAsync(string toEmail, string subject, string body)
        {
            var emailMessage = new MimeMessage();
            emailMessage.From.Add(new MailboxAddress("YourAppName", smtpUser));
            emailMessage.To.Add(new MailboxAddress("", toEmail));
            emailMessage.Subject = subject;

            var bodyBuilder = new BodyBuilder
            {
                HtmlBody = body // Set email body (HTML format)
            };

            emailMessage.Body = bodyBuilder.ToMessageBody();

            using (var client = new SmtpClient())
            {
                await client.ConnectAsync(smtpServer, smtpPort, MailKit.Security.SecureSocketOptions.StartTls).ConfigureAwait(false);
                await client.AuthenticateAsync(smtpUser, smtpPass).ConfigureAwait(false);
                await client.SendAsync(emailMessage).ConfigureAwait(false);
                await client.DisconnectAsync(true).ConfigureAwait(false);
            }
        }
    }
}


