using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PharmaPlus.Data;
using PharmaPlus.Filters;
using PharmaPlus.Models;
using PharmaPlus.Services;
using System.Security.Claims;

namespace PharmaPlus.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ServiceFilter(typeof(AdminAuthorizeAttribute))]
    public class AdminController : ControllerBase
    {
        private readonly PharmaPlusContext _context;
        private readonly EmailService _emailService;

        public AdminController(PharmaPlusContext context, EmailService emailService)
        {
            _context = context;
            _emailService = emailService;
        }

        // GET: api/Admin/orders
        [HttpGet("orders")]
        [Authorize]
        public async Task<ActionResult<IEnumerable<Order>>> GetOrders()
        {
            var orders = await _context.Orders
                .Include(o => o.OrderDetails)
                .ThenInclude(od => od.Drug)
                .Include(o => o.PlacedByUser) // Include user details

                .ToListAsync();

            var orderDtos = orders.Select(o => new Order
            {
                OrderId = o.OrderId,
                UserId = o.UserId,
                PlacedByUser = new User
                {
                    UserName = o.PlacedByUser.UserName, // Include user name
                    Contact = o.PlacedByUser.Contact, // Include user contact
                    Email = o.PlacedByUser.Email // Include user email
                },
                OrderDate = o.OrderDate,
                Status = o.Status,
                TotalAmount = o.TotalAmount,
                VerifiedBy = o.VerifiedBy,
                OrderDetails = o.OrderDetails.Select(od => new OrderDetail
                {
                    OrderDetailId = od.OrderDetailId,
                    DrugId = od.DrugId,
                    Quantity = od.Quantity,
                    UnitPrice = od.UnitPrice,
                    TotalPrice = od.TotalPrice
                }).ToList()
            }).ToList();

            return orderDtos;
        }

        // Approve orders from doctors
        [HttpPost("approveOrder/{orderId}")]
        [Authorize]
        public async Task<IActionResult> ApproveOrder(int orderId)
        {
            var username = GetLoggedInUsername();

            var user = await _context.Users.FirstOrDefaultAsync(u => u.UserName == username);
            if (user == null || !user.IsAdmin)
            {
                return Forbid("Only admins can approve orders.");
            }

            var order = await _context.Orders
                .Include(o => o.OrderDetails)
                .ThenInclude(od => od.Drug)
                .FirstOrDefaultAsync(o => o.OrderId == orderId);

            if (order == null)
            {
                return NotFound();
            }

            if (order.Status == "Approved")
            {
                return BadRequest("Order is already approved.");
            }

            // Check inventory and update quantities
            foreach (var orderDetail in order.OrderDetails)
            {
                var inventoryItem = await _context.InventoryLists
                    .FirstOrDefaultAsync(il => il.DrugId == orderDetail.DrugId);

                if (inventoryItem == null || inventoryItem.QuantityInStock < orderDetail.Quantity)
                {
                    return BadRequest($"Quantity not available for drug ID {orderDetail.DrugId}.");
                }

                inventoryItem.QuantityInStock -= orderDetail.Quantity;
                _context.Entry(inventoryItem).State = EntityState.Modified;
            }

            // Approve the order
            order.Status = "Approved";
            order.VerifiedBy = user.UserId;
            await _context.SaveChangesAsync();

             // Send email notification
            if (order.PlacedByUser != null && !string.IsNullOrEmpty(order.PlacedByUser.Email))
            {
                var subject = "Order Approved";
                var body = $"Your order with Order ID: {order.OrderId} has been approved.";
                await _emailService.SendEmailAsync(order.PlacedByUser.Email, subject, body);
            }
            return NoContent();
        }

        private string GetLoggedInUsername()
        {
            return User.FindFirst(ClaimTypes.Name)?.Value ?? "Unknown";
        }
    }
}