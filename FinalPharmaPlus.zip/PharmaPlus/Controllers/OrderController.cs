using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PharmaPlus.Data;
using PharmaPlus.Models;
using PharmaPlus.Services;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;

namespace PharmaPlus.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly PharmaPlusContext _context;
        private readonly EmailService _emailService;

        public OrderController(PharmaPlusContext context, EmailService emailService)
        {
            _context = context;
            _emailService = emailService;
        }

        // GET: api/Order
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Order>>> GetOrders()
        {
            var orders = await _context.Orders
                // .Include(o => o.VerifiedByUser)
                .Include(o => o.OrderDetails)
                .ThenInclude(od => od.Drug)
                .ToListAsync();

            var orderDtos = orders.Select(o => new Order
            {
                OrderId = o.OrderId,
                UserId = o.UserId,
                OrderDate = o.OrderDate,
                Status = o.Status,
                TotalAmount = o.TotalAmount,
                VerifiedBy = o.VerifiedBy,
                OrderDetails = o.OrderDetails.Select(od => new OrderDetail
                {
                    OrderDetailId = od.OrderDetailId,
                    DrugId = od.DrugId,
                    // DrugName = od.Drug.DrugName,
                    Quantity = od.Quantity,
                    UnitPrice = od.UnitPrice,
                    TotalPrice = od.TotalPrice
                }).ToList()
            }).ToList();

            return orderDtos;
        }

        // GET: api/Order/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Order>> GetOrder(int id)
        {
            var order = await _context.Orders
                .Include(o => o.PlacedByUser)
                .Include(o => o.VerifiedByUser)
                .Include(o => o.OrderDetails)
                .ThenInclude(od => od.Drug)
                .FirstOrDefaultAsync(o => o.OrderId == id);

            if (order == null)
            {
                return NotFound();
            }

            return order;
        }

        // POST: api/Order
        [HttpPost]
        [Authorize]
        public async Task<ActionResult<Order>> PostOrder(OrderRequest orderRequest)
        {
            var username = GetLoggedInUsername();

            var user = await _context.Users.FirstOrDefaultAsync(u => u.UserName == username);
            if (user == null)
            {
                return BadRequest("Invalid user. "+ username);
            }

            var order = new Order
            {
                UserId = user.UserId,
                PlacedByUser = user,
                OrderDate = DateTime.Now,
                Status = "Pending",
                OrderDetails = new List<OrderDetail>()
            };

            // Calculate the total amount
            decimal totalAmount = 0;
            foreach (var orderDetailRequest in orderRequest.OrderDetails)
            {
                var drug = await _context.Drugs.FirstOrDefaultAsync(d => d.DrugName == orderDetailRequest.DrugName);
                if (drug == null)
                {
                    return BadRequest($"Drug with name {orderDetailRequest.DrugName} not found.");
                }

                var orderDetail = new OrderDetail
                {
                    DrugId = drug.DrugId,
                    Drug = drug,
                    Quantity = orderDetailRequest.Quantity,
                    UnitPrice = drug.Price,
                    TotalPrice = drug.Price * orderDetailRequest.Quantity,
                    Order = order
                };

                order.OrderDetails.Add(orderDetail);
                totalAmount += orderDetail.TotalPrice;
            }
            order.TotalAmount = totalAmount;

            _context.Orders.Add(order);
            await _context.SaveChangesAsync();

            // Send email notification
            var subject = "New Order Placed";
            var body = $"A new order has been placed by {user.UserName}. Order ID: {order.OrderId}";
            await _emailService.SendEmailAsync(user.Email, subject, body);

            return CreatedAtAction(nameof(GetOrder), new { id = order.OrderId }, order);
        }

        // PUT: api/Order/5
        [HttpPut("{id}")]
        [Authorize]
        public async Task<IActionResult> PutOrder(int id, Order order)
        {
            if (id != order.OrderId)
            {
                return BadRequest();
            }

            _context.Entry(order).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!OrderExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // DELETE: api/Order/5
        [HttpDelete("{id}")]
        [Authorize]
        public async Task<IActionResult> DeleteOrder(int id)
        {
            var order = await _context.Orders.FindAsync(id);
            if (order == null)
            {
                return NotFound();
            }

            _context.Orders.Remove(order);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool OrderExists(int id)
        {
            return _context.Orders.Any(e => e.OrderId == id);
        }

        private string GetLoggedInUsername()
        {
            return User.FindFirst(ClaimTypes.Name)?.Value ?? "Unknown";
        }
    }

    public class OrderRequest
    {
        public List<OrderDetailRequest> OrderDetails { get; set; } = new List<OrderDetailRequest>();
    }

    public class OrderDetailRequest
    {
        public string DrugName { get; set; } = null!;
        public int Quantity { get; set; }
    }
}

