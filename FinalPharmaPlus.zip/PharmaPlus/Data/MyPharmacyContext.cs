using Microsoft.EntityFrameworkCore;
using PharmaPlus.Models;

namespace PharmaPlus.Data
{
    public partial class PharmaPlusContext : DbContext
    {
        public PharmaPlusContext(DbContextOptions<PharmaPlusContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Order> Orders { get; set; }
        public virtual DbSet<OrderDetail> OrderDetails { get; set; }
        public virtual DbSet<Drug> Drugs { get; set; }
        public virtual DbSet<Supplier> Suppliers { get; set; }
        public virtual DbSet<SalesReport> SalesReports { get; set; }
        public virtual DbSet<SalesReportDetail> SalesReportDetails { get; set; }
        public virtual DbSet<InventoryList> InventoryLists { get; set; }
        public virtual DbSet<User> Users { get; set; } // Add User DbSet

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure relationship between Order and User for PlacedByUser
            modelBuilder.Entity<Order>()
                .HasOne(o => o.PlacedByUser)
                .WithMany()
                .HasForeignKey(o => o.UserId)
                .OnDelete(DeleteBehavior.Restrict); // Specify delete behavior (Restrict, Cascade, etc.)

            // Configure relationship between Order and User for VerifiedByUser
            modelBuilder.Entity<Order>()
                .HasOne(o => o.VerifiedByUser)
                .WithMany()
                .HasForeignKey(o => o.VerifiedBy)
                .OnDelete(DeleteBehavior.Restrict); // Specify delete behavior
        }


    }
}