﻿
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PharmaPlus.Models
{
    public partial class SalesReportDetail
    {
        [Key]
        public int DetailId { get; set; }

        [ForeignKey("SalesReport")]
        public int ReportId { get; set; }

        [ForeignKey("Drug")]
        public int DrugId { get; set; }

        public int QuantitySold { get; set; }

        [Column(TypeName = "decimal(10, 2)")]
        public decimal UnitPrice { get; set; }

        [Column(TypeName = "decimal(10, 2)")]
        public decimal TotalPrice { get; set; }

        public virtual SalesReport SalesReport { get; set; } = null!; // Sales report to which this detail belongs

        public virtual Drug Drug { get; set; } = null!; // Drug in this detail
    }
}