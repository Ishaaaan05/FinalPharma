using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PharmaPlus.Data;
using PharmaPlus.Filters;
using PharmaPlus.Models;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace PharmaPlus.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class DrugController : ControllerBase
    {
        private readonly PharmaPlusContext _context;

        
        public DrugController(PharmaPlusContext context)
        {
            _context = context;

        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Drug>>> GetDrugs()
        {
            var drugs = await _context.Drugs
                .Include(d => d.Supplier) // Include the related Supplier entity
                .ToListAsync();

            if (drugs == null || !drugs.Any())
            {
                return NotFound();
            }

            return Ok(drugs);
        }

        [HttpGet("{id}")]
        
        public async Task<ActionResult<Drug>> GetDrug(int id)
        {
            var drug = await _context.Drugs
                .Include(d => d.Supplier) // Include the related Supplier entity
                .FirstOrDefaultAsync(d => d.DrugId == id);

            if (drug == null)
            {
                return NotFound();
            }

            return drug;
        }

        [HttpPost]
        [ServiceFilter(typeof(AdminAuthorizeAttribute))]

        [Authorize]
        public async Task<ActionResult<Drug>> PostDrug(Drug drug)
        {
            var username = GetLoggedInUsername();
            var user = await _context.Users.FirstOrDefaultAsync(u => u.UserName == username);
            if (user == null || !user.IsAdmin)
            {
                return Forbid( $"Only the user with the username 'Admin' can perform this action. Logged in as: {username}");
            }

            var existingDrug = await _context.Drugs
                .FirstOrDefaultAsync(d => d.DrugName == drug.DrugName && d.Manufacturer == drug.Manufacturer);

            if (existingDrug != null)
            {
                return BadRequest($"Drug already exists. Logged in as: {username}");
            }

            _context.Drugs.Add(drug);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetDrug), new { id = drug.DrugId }, drug);
        }

        [HttpPut("{id}")]
        [ServiceFilter(typeof(AdminAuthorizeAttribute))]

        [Authorize]
        public async Task<IActionResult> PutDrug(int id, Drug drug)
        {
            var username = GetLoggedInUsername();
            if (!IsAdminUser(username))
            {
                return StatusCode(403, $"Only the user with the username 'Admin' can perform this action. Logged in as: {username}");
            }

            if (id != drug.DrugId)
            {
                return BadRequest($"Invalid drug ID. Logged in as: {username}");
            }

            _context.Entry(drug).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!DrugExists(id))
                {
                    return NotFound($"Drug not found. Logged in as: {username}");
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        [HttpDelete("{id}")]
        [Authorize]
        public async Task<IActionResult> DeleteDrug(int id)
        {
            var username = GetLoggedInUsername();
            var user = await _context.Users.FirstOrDefaultAsync(u => u.UserName == username);
            if (user == null || !user.IsAdmin)
            {
                return Forbid( $"Only the user with the username 'Admin' can perform this action. Logged in as: {username}");
            }

            var drug = await _context.Drugs.FindAsync(id);
            if (drug == null)
            {
                return NotFound($"Drug not found. Logged in as: {username}");
            }

            _context.Drugs.Remove(drug);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool DrugExists(int id)
        {
            return _context.Drugs.Any(e => e.DrugId == id);
        }

        private bool IsAdminUser(string username)
        {
            return username == "Admin" || username == "Unknown";
        }

        private string GetLoggedInUsername()
        {
            return User.FindFirst(ClaimTypes.Name)?.Value ?? "Unknown";
        }
    }
}