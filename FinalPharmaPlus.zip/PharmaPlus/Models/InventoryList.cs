﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PharmaPlus.Models
{
    public class InventoryList
    {
        [Key]
        public int InventoryListId { get; set; }

        [ForeignKey("Drug")]
        public int DrugId { get; set; }

        [ForeignKey("Supplier")]
        public int SupplierId { get; set; }

        public int QuantityInStock { get; set; }

        [Column(TypeName = "decimal(10, 2)")]
        public decimal UnitPrice { get; set; }

        [Column(TypeName = "decimal(21, 2)")]
        public decimal TotalCost { get; set; }

        public int ReorderLevel { get; set; }

        [Column(TypeName = "datetime")]
        public DateTime? LastRestockDate { get; set; }

        [Column(TypeName = "date")]
        public DateTime ExpiryDate { get; set; } // Changed from DateOnly to DateTime for compatibility

        [ForeignKey("DrugId")]
        public virtual Drug Drug { get; set; } = null!;

        [ForeignKey("SupplierId")]
        public virtual Supplier Supplier { get; set; } = null!;
    }
}
