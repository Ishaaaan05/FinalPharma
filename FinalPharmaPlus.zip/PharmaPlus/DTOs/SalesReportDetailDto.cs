namespace PharmaPlus.DTOs
{
    public class SalesReportDetailDto
    {
        public int DetailId { get; set; }
        public int DrugId { get; set; }
        public int QuantitySold { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal TotalPrice { get; set; }
    }
}