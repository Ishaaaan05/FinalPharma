﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PharmaPlus.Models
{
    public partial class Drug
    {
        [Key]
        public int DrugId { get; set; }

        [Required]
        [StringLength(100)]
        public string DrugName { get; set; } = null!;

        public string? Description { get; set; }

        [Column(TypeName = "decimal(18, 2)")]
        public decimal Price { get; set; }

        [StringLength(100)]
        public string? Manufacturer { get; set; }

        [ForeignKey("Supplier")]
        public int? SupplierId { get; set; }

        public virtual Supplier? Supplier { get; set; }
    }
}
