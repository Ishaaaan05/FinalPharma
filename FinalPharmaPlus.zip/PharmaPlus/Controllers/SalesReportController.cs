using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using PharmaPlus.Data;
using PharmaPlus.DTOs;
using PharmaPlus.Filters;
using PharmaPlus.Models;


namespace MyPharmacy.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [ServiceFilter(typeof(AdminAuthorizeAttribute))]
    [Authorize]

    public class SalesReportController : ControllerBase
    {
        private readonly PharmaPlusContext _context;
        private readonly ILogger<SalesReportController> _logger;

        public SalesReportController(PharmaPlusContext context, ILogger<SalesReportController> logger)
        {
            _context = context;
            _logger = logger;
        }

        /// <summary>
        /// Gets all sales reports.
        /// </summary>
        /// <returns>A list of sales reports.</returns>
        [HttpGet]
        public async Task<ActionResult<IEnumerable<SalesReportDto>>> GetSalesReports()
        {
            try
            {
                var salesReports = await _context.SalesReports
                    .Include(sr => sr.SalesReportDetails)
                    .ToListAsync();

                var salesReportDtos = salesReports.Select(sr => new SalesReportDto
                {
                    ReportId = sr.ReportId,
                    AdminId = sr.AdminId,
                    GeneratedDate = sr.GeneratedDate,
                    TotalSales = sr.TotalSales,
                    TotalRevenue = sr.TotalRevenue,
                    TotalItemsSold = sr.TotalItemsSold,
                    SalesReportDetails = sr.SalesReportDetails.Select(srd => new SalesReportDetailDto
                    {
                        DetailId = srd.DetailId,
                        DrugId = srd.DrugId,
                        QuantitySold = srd.QuantitySold,
                        UnitPrice = srd.UnitPrice,
                        TotalPrice = srd.TotalPrice
                    }).ToList()
                }).ToList();

                return Ok(salesReportDtos);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while getting sales reports.");
                return StatusCode(500, "Internal server error");
            }
        }

        /// <summary>
        /// Gets a sales report by ID.
        /// </summary>
        /// <param name="id">The ID of the sales report.</param>
        /// <returns>The sales report with the specified ID.</returns>
        [HttpGet("{id}")]
        public async Task<ActionResult<SalesReportDto>> GetSalesReport(int id)
        {
            try
            {
                var salesReport = await _context.SalesReports
                    .Include(sr => sr.SalesReportDetails)
                    .FirstOrDefaultAsync(sr => sr.ReportId == id);

                if (salesReport == null)
                {
                    return NotFound();
                }

                var salesReportDto = new SalesReportDto
                {
                    ReportId = salesReport.ReportId,
                    AdminId = salesReport.AdminId,
                    GeneratedDate = salesReport.GeneratedDate,
                    TotalSales = salesReport.TotalSales,
                    TotalRevenue = salesReport.TotalRevenue,
                    TotalItemsSold = salesReport.TotalItemsSold,
                    SalesReportDetails = salesReport.SalesReportDetails.Select(srd => new SalesReportDetailDto
                    {
                        DetailId = srd.DetailId,
                        DrugId = srd.DrugId,
                        QuantitySold = srd.QuantitySold,
                        UnitPrice = srd.UnitPrice,
                        TotalPrice = srd.TotalPrice
                    }).ToList()
                };

                return Ok(salesReportDto);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"An error occurred while getting the sales report with ID {id}.");
                return StatusCode(500, "Internal server error");
            }
        }

        // POST: api/SalesReport/generate
        [HttpPost("generate")]
        public async Task<ActionResult<SalesReport>> GenerateSalesReport()
        {
            var now = DateTime.UtcNow;
            var startDate = new DateTime(now.Year, now.Month, 1); // First day of the current month

            var endDate = startDate.AddMonths(1).AddDays(-1); // Last day of the current month

            var totalSales = await _context.Orders.CountAsync(o => o.OrderDate >= startDate && o.OrderDate <= endDate);
            var totalRevenue = await _context.Orders
                .Where(o => o.OrderDate >= startDate && o.OrderDate <= endDate)
                .SumAsync(o => o.TotalAmount);
            var totalItemsSold = await _context.OrderDetails
                .Where(od => od.Order.OrderDate >= startDate && od.Order.OrderDate <= endDate)
                .SumAsync(od => od.Quantity);

            var salesReportDetails = await _context.OrderDetails
                .Where(od => od.Order.OrderDate >= startDate && od.Order.OrderDate <= endDate)
                .GroupBy(od => od.DrugId)
                .Select(g => new SalesReportDetail
                {
                    DrugId = g.Key,
                    QuantitySold = g.Sum(od => od.Quantity),
                    UnitPrice = g.First().UnitPrice,
                    TotalPrice = g.Sum(od => od.TotalPrice)
                })
                .ToListAsync();

            var salesReport = new SalesReport
            {
                AdminId = GetLoggedInAdminId(), // Assuming you have a method to get the logged-in admin's ID
                GeneratedDate = DateTime.UtcNow,
                TotalSales = totalSales,
                TotalRevenue = totalRevenue,
                TotalItemsSold = totalItemsSold,
                SalesReportDetails = salesReportDetails
            };

            _context.SalesReports.Add(salesReport);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetSalesReport), new { id = salesReport.ReportId }, salesReport);
        }

        // PUT: api/SalesReport/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutSalesReport(int id, SalesReport salesReport)
        {
            if (id != salesReport.ReportId)
            {
                return BadRequest();
            }

            _context.Entry(salesReport).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // DELETE: api/SalesReport/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteSalesReport(int id)
        {
            var salesReport = await _context.SalesReports.FindAsync(id);
            if (salesReport == null)
            {
                return NotFound();
            }

            _context.SalesReports.Remove(salesReport);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private int GetLoggedInAdminId()
        {
            // Implement logic to get the logged-in admin's ID
            // This is just a placeholder implementation
            return 2;
        }
    }
}
