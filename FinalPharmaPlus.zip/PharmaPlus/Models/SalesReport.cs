﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PharmaPlus.Models
{
    public class SalesReport
    {
        [Key]
        public int ReportId { get; set; }

        [ForeignKey("User")] // attribute to specify the foreign key
        public int AdminId { get; set; }

        
        public DateTime GeneratedDate { get; set; }

        [Column(TypeName = "decimal(18, 2)")] // attribute to specify the column data type and length of the decimal
        public decimal TotalSales { get; set; }

        [Column(TypeName = "decimal(18, 2)")]
        public decimal TotalRevenue { get; set; }

        public int TotalItemsSold { get; set; }

        public virtual ICollection<SalesReportDetail> SalesReportDetails { get; set; } = new List<SalesReportDetail>();
    }
}
