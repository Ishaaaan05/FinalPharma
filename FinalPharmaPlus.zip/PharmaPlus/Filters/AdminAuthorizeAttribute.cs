using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Linq;
using System.Security.Claims;

namespace PharmaPlus.Filters
{
    public class AdminAuthorizeAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            var isAdminClaim = context.HttpContext.User.FindFirst("IsAdmin")?.Value;
            if (isAdminClaim == null || !bool.TryParse(isAdminClaim, out bool isAdmin) || !isAdmin)
            {
                context.Result = new ForbidResult();
                return;
            }

            base.OnActionExecuting(context);
        }
    }
}